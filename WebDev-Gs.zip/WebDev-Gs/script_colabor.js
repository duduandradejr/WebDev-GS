
function openPopup() {
    document.getElementById("popup-design").style.display = "block";
    document.getElementById("popup").style.display = "block";
  }
  
  function closePopup() {
    document.getElementById("popup-design").style.display = "none";
    document.getElementById("popup").style.display = "none";
  }