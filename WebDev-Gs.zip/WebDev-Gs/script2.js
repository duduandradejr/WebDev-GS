var currentDate = new Date();
var formattedDate = currentDate.toLocaleString();
alert("Seja muito bem vindo(a)! Segue a data e a hora atual: " + formattedDate)

