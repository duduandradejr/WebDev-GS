function toggleDarkMode() {
    const body = document.querySelector('body');
    body.classList.toggle('dark-mode');
  }
  
  const darkModeButton = document.querySelector('.dark-mode-button');
  darkModeButton.addEventListener('click', toggleDarkMode);