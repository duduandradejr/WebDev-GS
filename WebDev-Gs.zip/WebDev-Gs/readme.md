# TRABALHO DA FACULDADE FIAP - GLOBAL SOLUTION
MEMBROS DO GRUPO : Eduardo Araujo (RM:99758) , Gabriel Doms (RM:98630) , Gabriela Trevisan (RM:99500) , Leonardo Correia (RM:550413) , Rafael Franck (RM:550875)


HTML, CSS e JavaScript A página foi criada com HTML5, CSS3 e JavaScript. O HTML foi estruturado de forma semântica, utilizando as tags apropriadas para cada elemento. O CSS foi utilizado para estilizar a página, definindo fontes, cores, tamanhos e posicionamentos. O JavaScript foi usado para interatividade, como a exibição de uma mensagem de boas-vindas ao usuário.

Phosphor-Icons Phosphor-Icons é uma biblioteca de ícones open-source, disponível em phosphoricons.com. Os ícones são criados com linhas finas, de alta qualidade e podem ser usados em projetos pessoais ou comerciais.

Como usar Clone ou faça o download deste repositório para sua máquina. Abra o arquivo index.html em um navegador de sua escolha. (Para melhor funcionamento utilize a extensão Live Server) A página será carregada e você poderá visualizar os ícones e interagir com a mensagem de boas-vindas.
